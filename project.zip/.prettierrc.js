module.exports = {
  plugins: ['prettier'],
  singleQuote: true,
  semi: true,
  trailingComma: 'all',
  printWidth: 80,
};
